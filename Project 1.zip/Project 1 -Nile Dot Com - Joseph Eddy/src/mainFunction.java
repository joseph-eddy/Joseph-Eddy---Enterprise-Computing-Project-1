/* 	Name: Joseph Eddy
	Course: CNT 4717 – Spring 2024
	Assignment Title: Project 1 – An Event-Driven Enterprise Simulation
	Date: Sunday January 28, 2024
*/

import java.io.File;

public class mainFunction {
	public static void main(String[] args) {
		
		File file = new File("inventory.csv");
		//Calls GUI to open
		guiWindow window = new guiWindow();
	}
}
